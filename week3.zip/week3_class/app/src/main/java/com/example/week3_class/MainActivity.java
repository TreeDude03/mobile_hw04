package com.example.week3_class;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.os.Bundle;
import android.os.Debug;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static Context context;
    private static int duration=Toast.LENGTH_SHORT;
    private Button btnReset ;
    private Button btnSignUp ;
    private Button btnSelectDate;

    private EditText edtUsername;
    private EditText edtPassword;
    private EditText edtRetype;
    private EditText edtBirthday;
    private RadioGroup rgGender;
    private CheckBox checkTennis;
    private CheckBox checkOthers;
    private CheckBox  checkFootball;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registerform);


        btnReset=findViewById(R.id.btnReset);
        btnSignUp=findViewById(R.id.btnSignUp);
        btnSelectDate=findViewById(R.id.btnSelectDate);

        edtUsername=findViewById(R.id.username);
        edtPassword=findViewById(R.id.password);
        edtRetype=findViewById(R.id.retype);
        edtBirthday=findViewById(R.id.birthday);
        rgGender=findViewById(R.id.gender);
        checkTennis=findViewById(R.id.tennis);
        checkFootball=findViewById(R.id.football);
        checkOthers=findViewById(R.id.others);

        btnReset.setOnClickListener(this);
        btnSignUp.setOnClickListener(this);
        btnSelectDate.setOnClickListener(this);
    }



    @Override
    public void onClick(View v) {
        if (v.getId() == btnSelectDate.getId()) {
            final Calendar calendar = Calendar.getInstance();
            int day = calendar.get(Calendar.DAY_OF_MONTH);
            int month = calendar.get(Calendar.MONTH);
            int year = calendar.get(Calendar.YEAR);
            //
            DatePickerDialog datePicker = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                    calendar.set(i,i1,i2);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.US);
                    edtBirthday.setText(dateFormat.format(calendar.getTime()));
                }
            },year,month,day);
            datePicker.show();
            return;
        }
        if (v.getId() == btnReset.getId()) {
            edtUsername.setText("");
            edtPassword.setText("");
            edtRetype.setText("");
            edtBirthday.setText("");
            rgGender.clearCheck();
            checkTennis.setChecked(false);
            checkTennis.setSelected(false);

            checkFootball.setChecked(false);
            checkFootball.setSelected(false);

            checkOthers.setChecked(false);
            checkOthers.setSelected(false);

            return;
        }

        if (v.getId() == btnSignUp.getId()) {
            if (!validDate(edtBirthday.getText().toString())) {
                context=getApplicationContext();
                Toast.makeText(context,"Ngày tháng không hợp lệ hoặc sai định dạng", duration).show();
                return;
            }
            if (isFullInfo()) {
                if (isRetypeCorrect()) {
                    // Tạo một Bundle và đặt các giá trị vào đó
                    Bundle bundle = new Bundle();
                    bundle.putString("username", edtUsername.getText().toString());
                    bundle.putString("password", edtPassword.getText().toString());
                    bundle.putString("birthday", edtBirthday.getText().toString());
                    RadioButton gender = findViewById(rgGender.getCheckedRadioButtonId());
                    bundle.putString("gender", gender.getText().toString());
                    bundle.putString("hobbies", checkHobbies());
                    // Tạo Intent để mở Activity B và đính kèm Bundle
                    Intent intent = new Intent(MainActivity.this, SignUpActivity.class);
                    intent.putExtras(bundle);
                    // Khởi động Activity B
                    startActivity(intent);
                }
                else {
                    context=getApplicationContext();
                    Toast.makeText(context,"Nhập lại mật khẩu sai",duration).show();
                }
            }
            else {
                context=getApplicationContext();
                Toast.makeText(context,"Hãy nhập đủ thông tin",duration).show();
            }
        }
    }


    public String checkHobbies() {
        String hobbies="";
        if (checkFootball.isChecked()) {
            hobbies=hobbies+ checkFootball.getText().toString();
        }
        if (checkTennis.isChecked()) {
            hobbies=hobbies+", "+checkTennis.getText().toString();
        }
        if (checkOthers.isChecked()) {
            hobbies=hobbies+", "+checkOthers.getText().toString();
        }
        if (hobbies.startsWith(",")) {
            hobbies=hobbies.substring(2);
        }
        return hobbies;
    }
    //Kiểm tra người dùng đã nhập ngày tháng đúng định dạng chưa
    private boolean validDate(String s) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        try {
            formatter.parse(s);
        }
        catch (Exception e) {
            return false;
        }

        String[] date=s.split("/");
        int day=Integer.valueOf(date[0]);
        int month=Integer.valueOf(date[1]);
        int year=Integer.valueOf(date[2]);

        if (month == 2) {
            if (year % 4 == 0 && year%100!=0 ) {
                // Năm nhuận, tháng 2 có 29 ngày
                return day >= 1 && day <= 29;
            } else {
                // Năm không nhuận, tháng 2 có 28 ngày
                return day >= 1 && day <= 28;
            }
        } else if (month == 4 || month == 6 || month == 9 || month == 11) {
            // Tháng 4, 6, 9, 11 có 30 ngày
            return day >= 1 && day <= 30;
        } else {
            // Các tháng khác có 31 ngày
            return day >= 1 && day <= 31;
        }
    }

    // Kiểm tra nhập lại mật khẩu đã đúng chưa
    private boolean isRetypeCorrect() {
        boolean check=true;
        if (!edtPassword.getText().toString().equals(edtRetype.getText().toString())) {
            check=false;
        }
        return check;
    }

    // Kiểm tra đã nhập đầy đủ thông tin chưa
    private boolean isFullInfo() {
        boolean check=true;
        if (edtUsername.getText().toString().isEmpty()) {
            check = false;
        }
        if (edtPassword.getText().toString().isEmpty()) {
            check=false;
        }
        if (edtRetype.getText().toString().isEmpty()){
            check=false;
        }

        if (rgGender.getCheckedRadioButtonId()==-1) {
            check=false;
        }
        if (!checkFootball.isChecked() && !checkTennis.isChecked() &&!checkOthers.isChecked()){
            check=false;
        }
        return check;
    }
}
